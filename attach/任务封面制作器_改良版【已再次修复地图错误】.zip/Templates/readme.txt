Loading Screen Template

Contents
  1. Asset Information
  2. Asset Description
  3. Terms & Conditions
  4. Installation & Usage
  5. Credits
  6. Disclaimer

===1. Asset Information===
*Author: Blade (Support by MooMan and Sleipnir)
*Filename(s): Too many to list
*Game(s) Supported: Red Alert2, Yuri's Revenge
*Editors Used: PSP 4
*Release Date: 12/02/2003

This asset is used for "The Project" modification for Yuri's Revenge.
This mod can be found at http://project.cannis.net (In development at time of writing)

===2. Asset Description===
This is a template asset that cannot be used as it is. With some creative thinking and using the brief instructions further down 
it is possible to use this template set to create Single Player campaign mission load screens that are highly consistent 
with the WestWood load screens found in Yuri's Revenge.

===3. Terms & Conditions===
If you choose to use this asset, either as is, or as a base for a modified asset, as part of a public release of a game modification, 
etc, then you MUST credit both the Author, "Blade" and the mod the asset belongs to (The Project) in your release's included or online documentation.

Redistribution is not permitted under any circumstances.

No limitations are placed on the use of this asset for private use.

===4. Installation & Usage===
Here is a very brief and condensed look at how to use this resource. 
If I ever have time I may make a more detailed set of instructions. 
A few things to bear in mind are that the elements are colour coded...
Blue means that that area is transparent, Green means that area has something pasted onto it later that you have to make yourself 
and yellow means that that colour gets changed to a side colour as detailed later. Anything else is actual image so it should be in the final version. 
You need to chop out a bit of map that is 800 pixels wide and 520 high (the maps are all 520 high but are much longer than 800 so they wrap)...
try to get the actual location you want the mission in just left of the centre of the selection. Next copy the selection to a new image 
and then load up the main image (side_Xicomain.png) and copy it with blue (RGB0,0,255) transparent onto the map...the main image is 800x520. 
The com_largetargetbox.png needs to be copied onto the load screen image that you are now in the process of making so that the upper 
left corner is at 346,52 co-ordinates, you need to have pasted a 234x232 screenshot from in game play of your map into the large green box 
before doing this though. The smalltargetbox goes over your target with blue transparent and you will need to alter the brightness, 
contrast and RGB values in the middle of the box (make it a selection) so that it shows the map lines as white. 
Use the common world map to make your enlarged map view for the large target box and paste the target shadow with blu transparent 
against the target box setting opacity to aroun 60% to create a shadow effect. Draw 2 pixel thickness lines with the line draw tool 
to link the large box to the small box as seen in WW maps. Paste on the target shields and arrows as you wish for the large target map and remap 
the yellow to the following colours in 24bit RGB, allied=97,80,255, soviet=206,0,0, yuri=206,30,250 (though these are just suggestions). 
Now paste the provided unit icons (or your own if you have a custom unit from a mod) as you desire (reflecting main units needed in the mission). 
Then just drop colour depth to 8bit with nearest colour matching and save as a PCX ready for conversion to both a pallet file and a .shp file 
to use in game by editing missionmd.ini (in YR).

FILE INSTALLATION:
Where ever it is most conveniant to access the file for an image editor from

===5. Credits===
-Westwood for a great game.

-Olaf for the XCC program suite nessesary to look at and modify game assets.

===6. Disclaimer===
The author does not make any warranties regarding the files in this archive. Users assume responsibility for the results achieved for computer program use and should verify applicability and accuracy.